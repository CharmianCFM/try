import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-aboutus',
  templateUrl: './aboutus.component.html',
  styleUrls: ['./aboutus.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AboutusComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
