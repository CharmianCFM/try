import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-room',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class RoomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
