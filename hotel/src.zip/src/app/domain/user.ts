export class User {
  id:string;
  idcard:string;
  phonenumber:string;
  email:string;
  password:string;
  usertype:string;
  expense:string;

}
