import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-foot',
  templateUrl: './foot.component.html',
  styleUrls: ['./foot.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class FootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
